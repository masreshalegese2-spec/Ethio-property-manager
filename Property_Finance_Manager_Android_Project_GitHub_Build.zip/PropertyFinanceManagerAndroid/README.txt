PROPERTY FINANCE MANAGER — ANDROID PROJECT

This is an Android WebView wrapper around your existing HTML app. It is a project source package, not an APK yet.

IMPORTANT: When uploading to GitHub, upload the CONTENTS of this ZIP to the ROOT of your repository. Do not upload the ZIP as a file and do not place the project inside another folder. The repository root must show settings.gradle, build.gradle, gradle.properties, app/ and .github/.

BUILD THE APK USING GITHUB (phone-friendly steps)
1. Download and extract this ZIP on your phone if your file manager supports extraction.
2. In your browser, open https://github.com and sign in.
3. Create a new repository. You may name it PropertyFinanceManagerAndroid. Public or private is fine.
4. Open the new repository. Choose Add file > Upload files.
5. Upload the project files and folders from inside the extracted folder, not the ZIP itself. At the top level you must see:
   - settings.gradle
   - build.gradle
   - gradle.properties
   - app/ (folder)
   - .github/workflows/build-apk.yml (workflow folder/file)
   If the website shows only one folder named PropertyFinanceManagerAndroid, open that folder and upload its contents instead, or move the files to the repository root.
6. Commit the files to the main branch (or master branch).
7. Open the repository's Actions tab. Select "Build Property Finance Manager APK". If asked, press "Run workflow".
8. Wait until the workflow completes successfully (green check mark).
9. Open that successful run, scroll to Artifacts, and download "Property-Finance-Manager-APK".
10. Extract the downloaded artifact ZIP. Inside is app-debug.apk. Tap it to install. Android may ask you to allow installation from your browser or file manager.

If the workflow fails, open the run and copy the red error text so it can be diagnosed.

NOTES
- The APK is unsigned for Play Store release but can be installed for testing on your own phone.
- This wrapper uses the original HTML file in app/src/main/assets/index.html.
- Keep backup copies of your finance records. Browser local data may not automatically transfer from the standalone HTML file into the app.
